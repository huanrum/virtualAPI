var views = require('./views');


module.exports =  function (configFn, helper){

    configFn('views',views);
};
